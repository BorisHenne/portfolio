#!/bin/bash
# ============================================================
# Script de déploiement FTP pour boris-henne.fr
# Usage: ./deploy-ftp.sh [--build]
# ============================================================

set -e

# Configuration FTP
FTP_HOST="91.216.107.79"
FTP_USER="boris1274039"
FTP_PASS="yG3_TGsY1s47RNX"  # Change ce mot de passe après le premier déploiement!
FTP_REMOTE_DIR="/"

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

echo ""
echo -e "${BLUE}==========================================${NC}"
echo -e "${BLUE}   Déploiement FTP boris-henne.fr${NC}"
echo -e "${BLUE}==========================================${NC}"
echo ""

# Build si demandé
if [[ "$1" == "--build" ]] || [ ! -d "dist" ]; then
    log_info "Compilation du projet..."
    npm install
    npm run build
    
    # Copier les assets
    cp public/profile.jpg dist/ 2>/dev/null || true
    cp public/favicon.svg dist/ 2>/dev/null || true
fi

# Vérifier dist
if [ ! -f "dist/index.html" ]; then
    log_error "Le fichier dist/index.html n'existe pas"
    exit 1
fi

# Vérifier lftp
if ! command -v lftp &> /dev/null; then
    log_error "lftp n'est pas installé"
    echo "Installation: apt install lftp (Debian/Ubuntu) ou brew install lftp (Mac)"
    exit 1
fi

log_info "Connexion à $FTP_HOST..."
log_info "Utilisateur: $FTP_USER"
echo ""

# Upload avec lftp
lftp -c "
set ftp:ssl-allow yes
set ssl:verify-certificate no
set ftp:passive-mode on
open -u $FTP_USER,$FTP_PASS $FTP_HOST
lcd dist
cd $FTP_REMOTE_DIR
mirror --reverse --delete --verbose --parallel=4
bye
"

echo ""
log_success "Déploiement terminé !"
echo ""
echo -e "Le site est accessible sur: ${GREEN}https://boris-henne.fr${NC}"
echo ""
