# Script de déploiement vers NAS UGreen
# Usage: .\deploy-nas.ps1 [-NasPath "\\192.168.x.x\docker\boris-portfolio"]

param(
    [string]$NasPath = "",
    [switch]$BuildOnly,
    [switch]$Help
)

$ErrorActionPreference = "Stop"

# Configuration par défaut
$DefaultNasPath = "\\NAS-UGREEN\docker\boris-portfolio"
$ProjectName = "boris-portfolio"

function Write-ColorOutput($ForegroundColor) {
    $fc = $host.UI.RawUI.ForegroundColor
    $host.UI.RawUI.ForegroundColor = $ForegroundColor
    if ($args) {
        Write-Output $args
    }
    $host.UI.RawUI.ForegroundColor = $fc
}

function Log-Info($message) {
    Write-Host "[INFO] " -NoNewline -ForegroundColor Blue
    Write-Host $message
}

function Log-Success($message) {
    Write-Host "[SUCCESS] " -NoNewline -ForegroundColor Green
    Write-Host $message
}

function Log-Error($message) {
    Write-Host "[ERROR] " -NoNewline -ForegroundColor Red
    Write-Host $message
}

function Log-Warning($message) {
    Write-Host "[WARNING] " -NoNewline -ForegroundColor Yellow
    Write-Host $message
}

function Show-Help {
    Write-Host ""
    Write-Host "Deploiement vers NAS UGreen" -ForegroundColor Cyan
    Write-Host "===========================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Usage: .\deploy-nas.ps1 [-NasPath <path>] [-BuildOnly] [-Help]"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -NasPath     Chemin reseau vers le NAS (ex: \\192.168.1.100\docker\boris-portfolio)"
    Write-Host "  -BuildOnly   Compile uniquement sans deployer"
    Write-Host "  -Help        Affiche cette aide"
    Write-Host ""
    Write-Host "Exemples:"
    Write-Host "  .\deploy-nas.ps1"
    Write-Host "  .\deploy-nas.ps1 -NasPath '\\192.168.1.29\docker\boris-portfolio'"
    Write-Host ""
}

function Check-NodeJS {
    Log-Info "Verification de Node.js..."
    try {
        $nodeVersion = node --version
        Log-Success "Node.js $nodeVersion detecte"
    }
    catch {
        Log-Error "Node.js n'est pas installe. Installez-le depuis https://nodejs.org/"
        exit 1
    }
}

function Install-Dependencies {
    Log-Info "Installation des dependances..."
    
    if (!(Test-Path "node_modules")) {
        npm install
        if ($LASTEXITCODE -ne 0) {
            Log-Error "Echec de l'installation des dependances"
            exit 1
        }
    }
    else {
        Log-Info "Les dependances sont deja installees"
    }
    
    Log-Success "Dependances prates"
}

function Build-Project {
    Log-Info "Compilation du projet React..."
    
    # Nettoyer le dossier dist
    if (Test-Path "dist") {
        Remove-Item -Recurse -Force "dist"
    }
    
    npm run build
    
    if ($LASTEXITCODE -ne 0) {
        Log-Error "Echec de la compilation"
        exit 1
    }
    
    Log-Success "Projet compile avec succes"
}

function Test-NasConnection($path) {
    Log-Info "Test de la connexion au NAS..."
    
    if (Test-Path $path) {
        Log-Success "Connexion au NAS etablie"
        return $true
    }
    else {
        Log-Warning "Impossible de se connecter a $path"
        return $false
    }
}

function Deploy-ToNas($nasPath) {
    Log-Info "Deploiement vers le NAS..."
    
    # Creer les dossiers sur le NAS si necessaires
    $folders = @("", "uploads", "logs")
    foreach ($folder in $folders) {
        $fullPath = Join-Path $nasPath $folder
        if (!(Test-Path $fullPath)) {
            New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
            Log-Info "Dossier cree: $folder"
        }
    }
    
    # Copier les fichiers de configuration Docker
    $configFiles = @(
        "Dockerfile",
        "docker-compose.yml",
        "nginx.conf",
        "deploy.sh"
    )
    
    foreach ($file in $configFiles) {
        if (Test-Path $file) {
            Copy-Item $file -Destination $nasPath -Force
            Log-Info "Copie: $file"
        }
    }
    
    # Copier le dossier dist
    $distSource = "dist\*"
    $distDest = Join-Path $nasPath "dist"
    
    if (Test-Path "dist") {
        if (!(Test-Path $distDest)) {
            New-Item -ItemType Directory -Path $distDest -Force | Out-Null
        }
        Copy-Item $distSource -Destination $distDest -Recurse -Force
        Log-Info "Copie: dist/"
    }
    
    # Copier la photo de profil si elle existe
    if (Test-Path "public\profile.jpg") {
        $profileDest = Join-Path $nasPath "dist"
        Copy-Item "public\profile.jpg" -Destination $profileDest -Force
        Log-Info "Copie: profile.jpg"
    }
    
    Log-Success "Fichiers deployes sur le NAS"
}

function Create-SshDeployScript {
    Log-Info "Creation du script de build distant..."
    
    $sshScript = @"
#!/bin/bash
cd /volume1/docker/boris-portfolio
docker-compose down || true
docker-compose build --no-cache
docker-compose up -d
docker image prune -f
echo "Deploiement termine!"
"@
    
    $sshScript | Out-File -FilePath "remote-build.sh" -Encoding UTF8 -NoNewline
    Log-Success "Script remote-build.sh cree"
}

# Main
function Main {
    if ($Help) {
        Show-Help
        return
    }
    
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host "   Deploiement $ProjectName" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""
    
    # Verifier qu'on est dans le bon dossier
    if (!(Test-Path "package.json")) {
        Log-Error "Executez ce script depuis le dossier du projet"
        exit 1
    }
    
    Check-NodeJS
    Install-Dependencies
    Build-Project
    
    if ($BuildOnly) {
        Log-Success "Compilation terminee (mode build-only)"
        return
    }
    
    # Determiner le chemin NAS
    $targetPath = if ($NasPath) { $NasPath } else { $DefaultNasPath }
    
    # Tester la connexion
    if (!(Test-NasConnection $targetPath)) {
        Log-Warning "Chemin NAS non accessible: $targetPath"
        Write-Host ""
        $userPath = Read-Host "Entrez le chemin reseau du NAS (ou appuyez sur Entree pour annuler)"
        
        if ([string]::IsNullOrEmpty($userPath)) {
            Log-Info "Deploiement annule. Les fichiers compiles sont dans ./dist/"
            Create-SshDeployScript
            return
        }
        
        $targetPath = $userPath
        
        if (!(Test-NasConnection $targetPath)) {
            Log-Error "Impossible de se connecter au NAS"
            exit 1
        }
    }
    
    Deploy-ToNas $targetPath
    Create-SshDeployScript
    
    Write-Host ""
    Log-Success "Deploiement termine !"
    Write-Host ""
    Write-Host "Prochaines etapes:" -ForegroundColor Yellow
    Write-Host "1. Connectez-vous en SSH au NAS"
    Write-Host "2. cd /volume1/docker/boris-portfolio  (ou le chemin equivalent)"
    Write-Host "3. chmod +x deploy.sh && ./deploy.sh"
    Write-Host ""
    Write-Host "Ou executez le script remote-build.sh via SSH"
    Write-Host ""
}

Main
