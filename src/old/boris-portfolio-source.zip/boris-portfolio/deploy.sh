#!/bin/bash
#
# Script de déploiement automatique pour boris-henne.fr
# Usage: ./deploy.sh [OPTIONS]
#
# Options:
#   --standalone    Utilise docker-compose.standalone.yml (port 8080)
#   --tunnel        Utilise docker-compose.tunnel.yml (avec Cloudflare intégré)
#   --build-only    Compile uniquement sans déployer
#   --restart       Redémarre uniquement le conteneur
#   --logs          Affiche les logs
#   --stop          Arrête le conteneur
#

set -e

# Configuration
CONTAINER_NAME="site-perso"
IMAGE_NAME="boris-portfolio"
COMPOSE_FILE="docker-compose.yml"

# Couleurs pour les logs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${CYAN}[STEP]${NC} $1"
}

# Vérifier si Docker est disponible
check_docker() {
    if ! command -v docker &> /dev/null; then
        log_error "Docker n'est pas installé ou accessible"
        exit 1
    fi
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        log_error "Docker Compose n'est pas installé"
        exit 1
    fi
    log_success "Docker est disponible"
}

# Déterminer la commande docker-compose
get_compose_cmd() {
    if docker compose version &> /dev/null; then
        echo "docker compose"
    else
        echo "docker-compose"
    fi
}

# Créer les dossiers nécessaires
create_directories() {
    log_step "Création des dossiers..."
    mkdir -p uploads logs
    touch uploads/.gitkeep
    log_success "Dossiers créés"
}

# Arrêter le conteneur existant
stop_container() {
    log_step "Arrêt du conteneur existant..."
    local compose_cmd=$(get_compose_cmd)
    $compose_cmd -f $COMPOSE_FILE down --remove-orphans 2>/dev/null || true
    log_success "Conteneur arrêté"
}

# Construire l'image
build_image() {
    log_step "Construction de l'image Docker..."
    local compose_cmd=$(get_compose_cmd)
    $compose_cmd -f $COMPOSE_FILE build --no-cache
    log_success "Image construite avec succès"
}

# Démarrer le conteneur
start_container() {
    log_step "Démarrage du conteneur..."
    local compose_cmd=$(get_compose_cmd)
    $compose_cmd -f $COMPOSE_FILE up -d
    log_success "Conteneur démarré"
}

# Vérifier la santé du conteneur
check_health() {
    log_step "Vérification de la santé du conteneur..."
    
    local max_attempts=30
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if docker ps -f name=$CONTAINER_NAME --format "{{.Status}}" | grep -q "healthy"; then
            log_success "Le conteneur est en bonne santé"
            return 0
        fi
        
        if [ $attempt -eq $max_attempts ]; then
            log_warning "Le conteneur n'est pas encore healthy après $max_attempts tentatives"
            log_info "Statut actuel: $(docker ps -f name=$CONTAINER_NAME --format '{{.Status}}')"
            return 1
        fi
        
        echo -n "."
        sleep 2
        ((attempt++))
    done
}

# Nettoyer les anciennes images
cleanup() {
    log_step "Nettoyage des anciennes images..."
    docker image prune -f
    log_success "Nettoyage terminé"
}

# Afficher les logs
show_logs() {
    log_info "Derniers logs du conteneur:"
    docker logs --tail 50 $CONTAINER_NAME
}

# Afficher l'aide
show_help() {
    echo ""
    echo -e "${CYAN}Déploiement boris-henne.fr${NC}"
    echo "================================"
    echo ""
    echo "Usage: ./deploy.sh [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --standalone    Utilise docker-compose.standalone.yml (expose port 8080)"
    echo "  --tunnel        Utilise docker-compose.tunnel.yml (Cloudflare intégré)"
    echo "  --build-only    Compile uniquement sans déployer"
    echo "  --restart       Redémarre uniquement le conteneur"
    echo "  --logs          Affiche les logs"
    echo "  --stop          Arrête le conteneur"
    echo "  --help          Affiche cette aide"
    echo ""
    echo "Exemples:"
    echo "  ./deploy.sh                      # Déploiement standard"
    echo "  ./deploy.sh --standalone         # Avec port 8080 exposé"
    echo "  ./deploy.sh --tunnel             # Avec Cloudflare tunnel intégré"
    echo ""
}

# Menu principal
main() {
    echo ""
    echo -e "${CYAN}==========================================${NC}"
    echo -e "${CYAN}   Déploiement boris-henne.fr${NC}"
    echo -e "${CYAN}==========================================${NC}"
    echo ""

    # Parser les arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            --standalone)
                COMPOSE_FILE="docker-compose.standalone.yml"
                log_info "Mode standalone (port 8080)"
                shift
                ;;
            --tunnel)
                COMPOSE_FILE="docker-compose.tunnel.yml"
                log_info "Mode tunnel Cloudflare intégré"
                if [ -z "$CLOUDFLARE_TUNNEL_TOKEN" ]; then
                    log_warning "Variable CLOUDFLARE_TUNNEL_TOKEN non définie"
                    log_info "Définissez-la avec: export CLOUDFLARE_TUNNEL_TOKEN='eyJ...'"
                fi
                shift
                ;;
            --build-only)
                check_docker
                build_image
                exit 0
                ;;
            --restart)
                check_docker
                stop_container
                start_container
                check_health
                exit 0
                ;;
            --logs)
                show_logs
                exit 0
                ;;
            --stop)
                check_docker
                stop_container
                exit 0
                ;;
            --help|-h)
                show_help
                exit 0
                ;;
            *)
                log_error "Option inconnue: $1"
                show_help
                exit 1
                ;;
        esac
    done

    log_info "Utilisation de: $COMPOSE_FILE"
    echo ""

    check_docker
    create_directories
    stop_container
    build_image
    start_container
    sleep 5
    check_health
    cleanup
    
    echo ""
    log_success "Déploiement terminé !"
    echo ""
    
    if [ "$COMPOSE_FILE" = "docker-compose.standalone.yml" ]; then
        echo -e "Le site est accessible sur:"
        echo -e "  ${GREEN}➜${NC} Local: http://localhost:8080"
        echo ""
        echo -e "${YELLOW}N'oublie pas de configurer ton tunnel Cloudflare:${NC}"
        echo "  Service: http://IP_NAS:8080"
    else
        echo -e "Le site est accessible sur:"
        echo -e "  ${GREEN}➜${NC} https://boris-henne.fr"
    fi
    echo ""
}

main "$@"
