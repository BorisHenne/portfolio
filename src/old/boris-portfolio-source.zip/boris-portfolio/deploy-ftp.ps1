# ============================================================
# Script de déploiement FTP pour boris-henne.fr
# Usage: .\deploy-ftp.ps1 [-BuildFirst]
# ============================================================

param(
    [switch]$BuildFirst,
    [switch]$Help
)

$ErrorActionPreference = "Stop"

# Configuration FTP
$FTP_HOST = "91.216.107.79"
$FTP_USER = "boris1274039"
$FTP_PASS = "yG3_TGsY1s47RNX"  # Change ce mot de passe après le premier déploiement!
$FTP_REMOTE_DIR = "/"

function Write-Success($msg) { Write-Host "[OK] $msg" -ForegroundColor Green }
function Write-Info($msg) { Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Warn($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err($msg) { Write-Host "[ERROR] $msg" -ForegroundColor Red }

function Show-Help {
    Write-Host ""
    Write-Host "Deploiement FTP boris-henne.fr" -ForegroundColor Cyan
    Write-Host "==============================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Usage: .\deploy-ftp.ps1 [-BuildFirst] [-Help]"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -BuildFirst    Compile le projet avant de deployer"
    Write-Host "  -Help          Affiche cette aide"
    Write-Host ""
    exit 0
}

if ($Help) { Show-Help }

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "   Deploiement FTP boris-henne.fr" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Build si demandé ou si dist n'existe pas
if ($BuildFirst -or !(Test-Path ".\dist")) {
    Write-Info "Compilation du projet..."
    npm install
    npm run build
    
    # Copier les assets
    Copy-Item ".\public\profile.jpg" ".\dist\" -Force -ErrorAction SilentlyContinue
    Copy-Item ".\public\favicon.svg" ".\dist\" -Force -ErrorAction SilentlyContinue
}

if (!(Test-Path ".\dist\index.html")) {
    Write-Err "Le fichier dist/index.html n'existe pas!"
    exit 1
}

Write-Info "Connexion a $FTP_HOST..."
Write-Info "Utilisateur: $FTP_USER"
Write-Host ""

# Créer le WebClient pour FTP
$webclient = New-Object System.Net.WebClient
$webclient.Credentials = New-Object System.Net.NetworkCredential($FTP_USER, $FTP_PASS)

# Fonction pour uploader un fichier
function Upload-File($localPath, $remotePath) {
    $uri = "ftp://$FTP_HOST$remotePath"
    try {
        $webclient.UploadFile($uri, $localPath)
        Write-Success "  $remotePath"
    }
    catch {
        Write-Err "  Erreur: $remotePath - $_"
    }
}

# Fonction pour créer un dossier FTP
function Create-FtpDirectory($path) {
    try {
        $uri = "ftp://$FTP_HOST$path"
        $request = [System.Net.FtpWebRequest]::Create($uri)
        $request.Method = [System.Net.WebRequestMethods+Ftp]::MakeDirectory
        $request.Credentials = New-Object System.Net.NetworkCredential($FTP_USER, $FTP_PASS)
        $response = $request.GetResponse()
        $response.Close()
    }
    catch {
        # Dossier existe probablement déjà
    }
}

Write-Info "Upload des fichiers..."

# Créer le dossier assets
Create-FtpDirectory "/assets"

# Lister et uploader tous les fichiers
Get-ChildItem -Path ".\dist" -Recurse -File | ForEach-Object {
    $relativePath = $_.FullName.Substring((Resolve-Path ".\dist").Path.Length).Replace("\", "/")
    Upload-File $_.FullName $relativePath
}

Write-Host ""
Write-Success "Deploiement termine!"
Write-Host ""
Write-Host "Le site est accessible sur:" -ForegroundColor Green
Write-Host "  https://boris-henne.fr" -ForegroundColor White
Write-Host ""
