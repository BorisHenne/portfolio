# Boris Henné - Portfolio Personnel

Portfolio moderne et responsive construit avec React, Tailwind CSS et Framer Motion.
Hébergé sur NAS UGreen avec Cloudflare Tunnel.

![React](https://img.shields.io/badge/React-18.3-61DAFB?logo=react)
![Tailwind](https://img.shields.io/badge/Tailwind-3.4-06B6D4?logo=tailwindcss)
![Docker](https://img.shields.io/badge/Docker-Ready-2496ED?logo=docker)
![Vite](https://img.shields.io/badge/Vite-5.4-646CFF?logo=vite)

## 🚀 Fonctionnalités

- **Design Cyberpunk/Tech** - Interface moderne avec effets néon et glass morphism
- **Responsive** - Optimisé mobile-first
- **Multilingue** - Français / English
- **Administration OAuth** - Connexion Google sécurisée pour mise à jour CV
- **Protection Anti-Scraping** - Email et téléphone protégés
- **Animations Fluides** - Framer Motion pour les transitions
- **SEO Ready** - Meta tags et Open Graph

## 📁 Structure du Projet

```
boris-portfolio/
├── src/
│   ├── components/     # Composants React
│   ├── hooks/          # Custom hooks
│   ├── i18n/           # Traductions FR/EN
│   ├── store/          # État global (Zustand)
│   ├── styles/         # CSS global
│   └── utils/          # Utilitaires
├── public/             # Assets statiques
├── docker-compose.yml  # Configuration Docker
├── Dockerfile          # Build multi-stage
├── nginx.conf          # Configuration Nginx
└── deploy.sh           # Script de déploiement
```

## 🛠️ Installation Locale

### Prérequis

- Node.js 18+
- npm ou yarn

### Développement

```bash
# Cloner le projet
git clone https://github.com/borishenne/portfolio.git
cd portfolio

# Installer les dépendances
npm install

# Lancer en mode développement
npm run dev
```

Le site sera accessible sur `http://localhost:5173`

### Build Production

```bash
npm run build
```

## 🐳 Déploiement Docker (NAS UGreen)

### Option 1 : Déploiement Automatique (Windows)

```powershell
# Depuis PowerShell
.\deploy-nas.ps1 -NasPath "\\192.168.1.XX\docker\boris-portfolio"
```

### Option 2 : Déploiement Manuel

1. **Copier les fichiers sur le NAS :**

```bash
# Via SSH ou partage réseau, copier :
# - docker-compose.yml
# - Dockerfile
# - nginx.conf
# - deploy.sh
# - Tout le code source
```

2. **Sur le NAS (SSH) :**

```bash
cd /volume1/docker/boris-portfolio
chmod +x deploy.sh
./deploy.sh
```

3. **Le site sera accessible sur le port 8080**

### Configuration Cloudflare Tunnel

1. Créer un tunnel sur [Cloudflare Zero Trust](https://one.dash.cloudflare.com/)
2. Configurer le tunnel pour pointer vers `http://site-perso:80`
3. Ajouter le token dans docker-compose.yml ou via variables d'environnement

## ⚙️ Configuration

### Variables d'Environnement

Créez un fichier `.env` à partir de `.env.example` :

```env
# Google OAuth (pour l'administration)
VITE_GOOGLE_CLIENT_ID=your_client_id

# Cloudflare Tunnel (optionnel)
CLOUDFLARE_TUNNEL_TOKEN=your_token
```

### Configuration Google OAuth

1. Aller sur [Google Cloud Console](https://console.cloud.google.com/)
2. Créer un projet ou en sélectionner un existant
3. APIs & Services > Credentials > Create Credentials > OAuth 2.0 Client IDs
4. Type: Web application
5. Authorized JavaScript origins: `https://boris-henne.fr`
6. Copier le Client ID dans `.env`

## 📱 Captures d'écran

### Desktop
![Desktop](./screenshots/desktop.png)

### Mobile
![Mobile](./screenshots/mobile.png)

## 🔒 Sécurité

- **Protection des contacts** : Email et téléphone encodés, décodés côté client uniquement
- **OAuth sécurisé** : Seul boris.henne@gmail.com peut accéder à l'admin
- **Headers de sécurité** : CSP, X-Frame-Options, etc.
- **HTTPS** : Via Cloudflare Tunnel

## 📄 Licence

Ce projet est privé. © Boris Henné 2025

## 📞 Contact

- **Email** : boris.henne@gmail.com
- **LinkedIn** : [/in/borishenne](https://www.linkedin.com/in/borishenne/)
- **Site** : [boris-henne.fr](https://boris-henne.fr)
