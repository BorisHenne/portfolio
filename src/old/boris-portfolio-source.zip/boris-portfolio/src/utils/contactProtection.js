// Protection anti-scraping pour les informations de contact
// Les données sont encodées et décodées côté client uniquement

const encode = (str) => {
  return btoa(str.split('').reverse().join(''));
};

const decode = (str) => {
  try {
    return atob(str).split('').reverse().join('');
  } catch {
    return '';
  }
};

// Données encodées (inversées puis base64)
const PROTECTED_DATA = {
  email: 'bW9jLmxpYW1nQGVubmVoLnNpcm9i',
  emailPro: 'dWUuY21iZUBibmVoLmI=',
  phone: 'ODIgMzUgMDcgNjAgNiAzMys=',
};

export const getContactInfo = () => {
  return {
    email: decode(PROTECTED_DATA.email),
    emailPro: decode(PROTECTED_DATA.emailPro),
    phone: decode(PROTECTED_DATA.phone),
  };
};

// Génère un mailto: protégé
export const getMailtoLink = (type = 'personal') => {
  const email = type === 'pro' 
    ? decode(PROTECTED_DATA.emailPro) 
    : decode(PROTECTED_DATA.email);
  return `mailto:${email}`;
};

// Génère un tel: protégé
export const getTelLink = () => {
  const phone = decode(PROTECTED_DATA.phone);
  return `tel:${phone.replace(/\s/g, '')}`;
};

// Affiche le numéro de façon fragmentée pour éviter le scraping simple
export const getObfuscatedPhone = () => {
  const phone = decode(PROTECTED_DATA.phone);
  return phone;
};

export const getObfuscatedEmail = (type = 'personal') => {
  const email = type === 'pro' 
    ? decode(PROTECTED_DATA.emailPro) 
    : decode(PROTECTED_DATA.email);
  return email;
};
