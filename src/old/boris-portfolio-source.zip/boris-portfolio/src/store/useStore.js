import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useAppStore = create(
  persist(
    (set) => ({
      // Auth state
      isAuthenticated: false,
      user: null,
      
      // UI state
      isMenuOpen: false,
      activeSection: 'home',
      
      // Actions
      setAuthenticated: (isAuthenticated, user = null) => 
        set({ isAuthenticated, user }),
      
      logout: () => 
        set({ isAuthenticated: false, user: null }),
      
      toggleMenu: () => 
        set((state) => ({ isMenuOpen: !state.isMenuOpen })),
      
      closeMenu: () => 
        set({ isMenuOpen: false }),
      
      setActiveSection: (section) => 
        set({ activeSection: section }),
    }),
    {
      name: 'boris-portfolio-storage',
      partialize: (state) => ({ 
        isAuthenticated: state.isAuthenticated,
        user: state.user 
      }),
    }
  )
);

export const useLanguageStore = create(
  persist(
    (set) => ({
      language: 'fr',
      setLanguage: (language) => set({ language }),
    }),
    {
      name: 'boris-portfolio-lang',
    }
  )
);
