import { useState, useEffect } from 'react';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { useTranslation } from 'react-i18next';
import { useLanguageStore } from './store/useStore';

// Components
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Experience from './components/Experience';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Contact from './components/Contact';
import Footer from './components/Footer';
import AdminModal from './components/AdminModal';

// Google OAuth Client ID
const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID || '';
const isOAuthConfigured = GOOGLE_CLIENT_ID && GOOGLE_CLIENT_ID.includes('.apps.googleusercontent.com');

function AppContent({ onAdminClick }) {
  const { i18n } = useTranslation();
  const { language } = useLanguageStore();
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  // Synchroniser la langue au chargement
  useEffect(() => {
    i18n.changeLanguage(language);
    
    // Animation de chargement
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className={`min-h-screen bg-[#0a0f0d] transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
      {/* Background Elements */}
      <div className="fixed inset-0 grid-bg opacity-30 pointer-events-none" />
      <div className="fixed inset-0 bg-gradient-to-br from-[#00ff88]/5 via-transparent to-[#14b8a6]/5 pointer-events-none" />
      
      {/* Main Content */}
      <Header onAdminClick={() => setIsAdminModalOpen(true)} />
      
      <main>
        <Hero />
        <About />
        <Experience />
        <Skills />
        <Projects />
        <Contact />
      </main>
      
      <Footer />
      
      {/* Admin Modal */}
      <AdminModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
      />
    </div>
  );
}

function App() {
  // Ne charger GoogleOAuthProvider que si configuré
  if (isOAuthConfigured) {
    return (
      <GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
        <AppContent />
      </GoogleOAuthProvider>
    );
  }
  
  // Sans OAuth, rendre directement l'app
  return <AppContent />;
}

export default App;
