import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { X, Upload, FileText, AlertCircle, Settings, CheckCircle } from 'lucide-react';
import { GoogleLogin } from '@react-oauth/google';
import { useAppStore } from '../store/useStore';
import { useState } from 'react';

// Email autorisé pour l'admin - UNIQUEMENT TOI
const ALLOWED_EMAIL = 'boris.henne@gmail.com';

// Vérifier si le Client ID est configuré
const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const isOAuthConfigured = GOOGLE_CLIENT_ID && GOOGLE_CLIENT_ID !== 'YOUR_GOOGLE_CLIENT_ID' && GOOGLE_CLIENT_ID.includes('.apps.googleusercontent.com');

export default function AdminModal({ isOpen, onClose }) {
  const { t } = useTranslation();
  const { isAuthenticated, user, setAuthenticated, logout } = useAppStore();
  const [error, setError] = useState(null);
  const [uploadStatus, setUploadStatus] = useState(null);

  const handleGoogleSuccess = (credentialResponse) => {
    try {
      // Décoder le JWT pour obtenir les infos utilisateur
      const base64Url = credentialResponse.credential.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(
        atob(base64)
          .split('')
          .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      const decoded = JSON.parse(jsonPayload);

      console.log('Google login:', decoded.email); // Debug

      // Vérifier si l'email est autorisé (UNIQUEMENT boris.henne@gmail.com)
      if (decoded.email.toLowerCase() === ALLOWED_EMAIL.toLowerCase()) {
        setAuthenticated(true, {
          name: decoded.name,
          email: decoded.email,
          picture: decoded.picture,
        });
        setError(null);
      } else {
        setError(`Accès refusé. Seul ${ALLOWED_EMAIL} peut se connecter.`);
        console.warn('Unauthorized login attempt:', decoded.email);
      }
    } catch (err) {
      console.error('OAuth decode error:', err);
      setError('Erreur lors de la connexion. Réessayez.');
    }
  };

  const handleGoogleError = () => {
    setError('Erreur de connexion Google. Vérifiez que le Client ID est correct.');
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      setUploadStatus({ type: 'error', message: 'Seuls les fichiers PDF sont acceptés.' });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setUploadStatus({ type: 'error', message: 'Le fichier est trop volumineux (max 5 Mo).' });
      return;
    }

    setUploadStatus({ type: 'uploading', message: 'Téléversement en cours...' });

    // Créer un lien de téléchargement pour le fichier
    // En production, tu pourrais envoyer vers un backend ou un storage cloud
    try {
      const url = URL.createObjectURL(file);
      
      // Simuler un délai d'upload
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setUploadStatus({ 
        type: 'success', 
        message: 'CV prêt ! Pour le déployer, remplace le fichier cv-boris-henne.pdf sur le serveur.',
        url: url,
        filename: file.name
      });
    } catch (err) {
      setUploadStatus({ type: 'error', message: 'Erreur lors du téléversement.' });
    }
  };

  const downloadCV = () => {
    if (uploadStatus?.url) {
      const a = document.createElement('a');
      a.href = uploadStatus.url;
      a.download = 'cv-boris-henne.pdf';
      a.click();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-x-4 top-1/2 -translate-y-1/2 mx-auto max-w-md z-50"
          >
            <div className="glass-card rounded-2xl p-5 sm:p-8 max-h-[85vh] overflow-y-auto">
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-display text-xl text-white">
                  {t('admin.login')}
                </h2>
                <button
                  onClick={onClose}
                  className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              {isAuthenticated && user ? (
                /* Authenticated View */
                <div className="space-y-6">
                  {/* User Info */}
                  <div className="flex items-center gap-4 p-4 rounded-xl bg-[#00ff88]/10 border border-[#00ff88]/30">
                    {user.picture && (
                      <img
                        src={user.picture}
                        alt={user.name}
                        className="w-12 h-12 rounded-full border-2 border-[#00ff88]"
                      />
                    )}
                    <div>
                      <p className="text-white font-medium">{user.name}</p>
                      <p className="text-gray-400 text-sm">{user.email}</p>
                    </div>
                    <CheckCircle className="ml-auto text-[#00ff88]" size={24} />
                  </div>

                  {/* CV Upload */}
                  <div>
                    <h3 className="font-mono text-[#00ff88] text-sm mb-3">
                      {t('admin.updateCV')}
                    </h3>
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-[#00ff88]/30 rounded-xl cursor-pointer hover:bg-[#00ff88]/5 transition-colors">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <Upload className="w-8 h-8 text-[#00ff88] mb-2" />
                        <p className="text-sm text-gray-400">
                          <span className="text-[#00ff88]">Cliquer</span> ou glisser-déposer
                        </p>
                        <p className="text-xs text-gray-600 mt-1">PDF uniquement (max 5 Mo)</p>
                      </div>
                      <input
                        type="file"
                        className="hidden"
                        accept=".pdf"
                        onChange={handleFileUpload}
                      />
                    </label>

                    {/* Upload Status */}
                    {uploadStatus && (
                      <div
                        className={`mt-3 p-3 rounded-lg text-sm ${
                          uploadStatus.type === 'success'
                            ? 'bg-green-500/20 text-green-400'
                            : uploadStatus.type === 'error'
                            ? 'bg-red-500/20 text-red-400'
                            : 'bg-[#00ff88]/20 text-[#00ff88]'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {uploadStatus.type === 'uploading' ? (
                            <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <FileText size={16} />
                          )}
                          {uploadStatus.message}
                        </div>
                        {uploadStatus.type === 'success' && uploadStatus.url && (
                          <button
                            onClick={downloadCV}
                            className="mt-2 text-xs underline hover:no-underline"
                          >
                            Télécharger le CV
                          </button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Logout Button */}
                  <button
                    onClick={() => {
                      logout();
                      setUploadStatus(null);
                    }}
                    className="w-full btn-cyber"
                  >
                    {t('admin.logout')}
                  </button>
                </div>
              ) : !isOAuthConfigured ? (
                /* OAuth Not Configured */
                <div className="space-y-6">
                  <div className="p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/30">
                    <div className="flex items-start gap-3">
                      <Settings className="text-yellow-500 mt-0.5" size={20} />
                      <div>
                        <p className="text-yellow-400 font-medium mb-2">Configuration requise</p>
                        <p className="text-gray-400 text-sm">
                          Pour activer l'authentification Google, crée un fichier <code className="text-[#00ff88]">.env</code> avec :
                        </p>
                        <pre className="mt-2 p-2 bg-[#0a0f0d] rounded text-xs text-[#00ff88] overflow-x-auto">
                          VITE_GOOGLE_CLIENT_ID=ton_client_id.apps.googleusercontent.com
                        </pre>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-gray-500 text-xs">
                    <p className="mb-2">Pour obtenir un Client ID :</p>
                    <ol className="list-decimal list-inside space-y-1">
                      <li>Va sur <a href="https://console.cloud.google.com/" target="_blank" rel="noopener noreferrer" className="text-[#00ff88] hover:underline">Google Cloud Console</a></li>
                      <li>APIs & Services → Credentials</li>
                      <li>Create Credentials → OAuth 2.0 Client IDs</li>
                      <li>Ajoute <code>https://boris-henne.fr</code> dans les origines autorisées</li>
                    </ol>
                  </div>
                </div>
              ) : (
                /* Login View */
                <div className="space-y-6">
                  <p className="text-gray-400 text-sm text-center">
                    Connectez-vous avec votre compte Google pour accéder à l'administration.
                  </p>

                  {/* Error Message */}
                  {error && (
                    <div className="p-3 rounded-lg bg-red-500/20 border border-red-500/30 flex items-start gap-2 text-red-400 text-sm">
                      <AlertCircle size={16} className="mt-0.5 flex-shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  {/* Google Login */}
                  <div className="flex justify-center">
                    <GoogleLogin
                      onSuccess={handleGoogleSuccess}
                      onError={handleGoogleError}
                      theme="filled_black"
                      shape="pill"
                      text="signin_with"
                      locale="fr"
                      useOneTap={false}
                    />
                  </div>

                  <p className="text-gray-600 text-xs text-center">
                    Seul <span className="text-[#00ff88]">{ALLOWED_EMAIL}</span> peut se connecter.
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
