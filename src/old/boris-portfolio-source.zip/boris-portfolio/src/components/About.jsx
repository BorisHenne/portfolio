import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Music, Home, Brain, Workflow, Code, Calendar, FolderGit, Award } from 'lucide-react';

const interestIcons = {
  music: Music,
  domotics: Home,
  ai: Brain,
  automation: Workflow,
  dev: Code,
};

export default function About() {
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const stats = [
    { value: '12+', label: t('about.years'), icon: Calendar },
    { value: '50+', label: t('about.projects'), icon: FolderGit },
    { value: '30+', label: t('about.certifications'), icon: Award },
  ];

  const interests = ['music', 'domotics', 'ai', 'automation', 'dev'];

  return (
    <section id="about" className="py-20 lg:py-32 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            <span className="text-[#00ff88]">{'<'}</span>
            {t('about.title')}
            <span className="text-[#00ff88]">{' />'}</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-[#00ff88] to-[#14b8a6] mx-auto rounded-full" />
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column - Text */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="glass-card rounded-2xl p-6 sm:p-8">
              <p className="text-lg text-gray-300 mb-6 leading-relaxed">
                {t('about.intro')}
              </p>
              <p className="text-gray-400 leading-relaxed">
                {t('about.description')}
              </p>

              {/* Interests */}
              <div className="mt-8">
                <h3 className="font-display text-[#00ff88] text-lg mb-4">
                  {t('about.interests')}
                </h3>
                <div className="flex flex-wrap gap-3">
                  {interests.map((interest, index) => {
                    const Icon = interestIcons[interest];
                    return (
                      <motion.div
                        key={interest}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={isInView ? { opacity: 1, scale: 1 } : {}}
                        transition={{ delay: 0.4 + index * 0.1 }}
                        className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#00ff88]/10 border border-[#00ff88]/30 text-sm text-gray-300"
                      >
                        <Icon size={16} className="text-[#00ff88]" />
                        {t(`about.interestsList.${interest}`)}
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Column - Stats */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="grid grid-cols-1 sm:grid-cols-3 gap-6"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.6 + index * 0.15 }}
                className="glass-card rounded-2xl p-6 text-center group"
              >
                <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-[#00ff88]/10 border border-[#00ff88]/30 flex items-center justify-center group-hover:bg-[#00ff88]/20 transition-colors">
                  <stat.icon size={28} className="text-[#00ff88]" />
                </div>
                <div className="font-display text-4xl font-bold text-white mb-2">
                  {stat.value}
                </div>
                <div className="font-mono text-sm text-gray-400">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-20 right-10 w-32 h-32 border border-[#00ff88]/10 rounded-full hidden lg:block" />
        <div className="absolute bottom-20 left-10 w-20 h-20 bg-[#00ff88]/5 rounded-full hidden lg:block" />
      </div>
    </section>
  );
}
