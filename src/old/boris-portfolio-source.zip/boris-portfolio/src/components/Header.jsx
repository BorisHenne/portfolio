import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Menu, X, Globe, User, LogOut } from 'lucide-react';
import { useAppStore, useLanguageStore } from '../store/useStore';

const navItems = ['home', 'about', 'experience', 'skills', 'projects', 'contact'];

export default function Header({ onAdminClick }) {
  const { t, i18n } = useTranslation();
  const [scrolled, setScrolled] = useState(false);
  const { isMenuOpen, toggleMenu, closeMenu, isAuthenticated, logout, user } = useAppStore();
  const { language, setLanguage } = useLanguageStore();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const changeLanguage = () => {
    const newLang = language === 'fr' ? 'en' : 'fr';
    setLanguage(newLang);
    i18n.changeLanguage(newLang);
    localStorage.setItem('language', newLang);
  };

  const scrollToSection = (sectionId) => {
    closeMenu();
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'glass py-3' : 'py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <motion.a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('home');
              }}
              className="flex items-center gap-2 group"
              whileHover={{ scale: 1.05 }}
            >
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#00ff88] to-[#14b8a6] flex items-center justify-center font-display font-bold text-[#0a0f0d]">
                BH
              </div>
              <span className="hidden sm:block font-display text-[#00ff88] group-hover:neon-text transition-all">
                Boris Henné
              </span>
            </motion.a>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => (
                <motion.button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className="px-4 py-2 font-mono text-sm text-gray-300 hover:text-[#00ff88] transition-colors relative group"
                  whileHover={{ y: -2 }}
                >
                  {t(`nav.${item}`)}
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-[#00ff88] group-hover:w-full transition-all duration-300" />
                </motion.button>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2 sm:gap-4">
              {/* Language Toggle */}
              <motion.button
                onClick={changeLanguage}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#00ff88]/30 text-[#00ff88] hover:bg-[#00ff88]/10 transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Globe size={16} />
                <span className="text-xs font-mono uppercase">{language}</span>
              </motion.button>

              {/* Admin Button */}
              {isAuthenticated ? (
                <div className="hidden sm:flex items-center gap-2">
                  <span className="text-xs text-gray-400 font-mono">
                    {user?.name?.split(' ')[0]}
                  </span>
                  <motion.button
                    onClick={logout}
                    className="p-2 rounded-lg border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-colors"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <LogOut size={16} />
                  </motion.button>
                </div>
              ) : (
                <motion.button
                  onClick={onAdminClick}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#00ff88]/30 text-gray-400 hover:text-[#00ff88] hover:bg-[#00ff88]/10 transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <User size={16} />
                  <span className="text-xs font-mono">Admin</span>
                </motion.button>
              )}

              {/* Mobile Menu Button */}
              <motion.button
                onClick={toggleMenu}
                className="lg:hidden p-2 rounded-lg border border-[#00ff88]/50 text-[#00ff88] hover:bg-[#00ff88]/10 transition-colors"
                whileTap={{ scale: 0.95 }}
                aria-label="Menu"
              >
                {isMenuOpen ? <X size={22} /> : <Menu size={22} />}
              </motion.button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25 }}
            className="fixed inset-0 z-40 lg:hidden"
          >
            <div 
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={closeMenu}
            />
            <motion.nav
              className="absolute right-0 top-0 bottom-0 w-72 glass-card flex flex-col"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
            >
              <div className="p-6 pt-20 flex flex-col gap-2">
                {navItems.map((item, index) => (
                  <motion.button
                    key={item}
                    onClick={() => scrollToSection(item)}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="px-4 py-3 text-left font-mono text-gray-300 hover:text-[#00ff88] hover:bg-[#00ff88]/10 rounded-lg transition-colors"
                  >
                    {t(`nav.${item}`)}
                  </motion.button>
                ))}
                
                <div className="mt-4 pt-4 border-t border-[#00ff88]/20">
                  {isAuthenticated ? (
                    <button
                      onClick={() => {
                        logout();
                        closeMenu();
                      }}
                      className="w-full px-4 py-3 text-left font-mono text-red-400 hover:bg-red-500/10 rounded-lg transition-colors flex items-center gap-2"
                    >
                      <LogOut size={18} />
                      {t('admin.logout')}
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        onAdminClick();
                        closeMenu();
                      }}
                      className="w-full px-4 py-3 text-left font-mono text-gray-400 hover:text-[#00ff88] hover:bg-[#00ff88]/10 rounded-lg transition-colors flex items-center gap-2"
                    >
                      <User size={18} />
                      {t('admin.login')}
                    </button>
                  )}
                </div>
              </div>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
