import { motion, useInView } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useRef, useState, useEffect } from 'react';
import { ExternalLink, Github, Play, Wifi, WifiOff, Download } from 'lucide-react';
import Icon from '@mdi/react';
import { 
  mdiDomain,           // EBMC - entreprise
  mdiBasket,           // Léopold - panier
  mdiCubeOutline,      // Raytracing - 3D
  mdiMemory,           // LibASM - assembleur/mémoire
  mdiHomeAutomation,   // Home Assistant
  mdiMusic,            // Suno AI Music
  mdiWeb,              // Portfolio
  mdiSchool,           // 42 - école
  mdiOfficeBuilding    // SAP - entreprise
} from '@mdi/js';

// Composant VideoPlayer intelligent - économise la data mobile
function VideoPlayer() {
  const { i18n } = useTranslation();
  const [loadVideo, setLoadVideo] = useState(false);
  const [connectionType, setConnectionType] = useState('unknown');
  const [isSlowConnection, setIsSlowConnection] = useState(false);
  const videoRef = useRef(null);

  useEffect(() => {
    // Détecter le type de connexion
    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    
    if (connection) {
      const updateConnectionInfo = () => {
        const type = connection.effectiveType || connection.type || 'unknown';
        setConnectionType(type);
        
        // Connexion lente = 2g, slow-2g, ou saveData activé
        const slow = ['slow-2g', '2g', '3g'].includes(type) || connection.saveData;
        setIsSlowConnection(slow);
        
        // Sur WiFi/4G desktop, charger automatiquement
        if (!slow && window.innerWidth > 1024) {
          setLoadVideo(true);
        }
      };
      
      updateConnectionInfo();
      connection.addEventListener('change', updateConnectionInfo);
      return () => connection.removeEventListener('change', updateConnectionInfo);
    } else {
      // Pas d'API Connection - on se base sur la taille d'écran
      // Desktop = probablement WiFi, Mobile = on demande
      if (window.innerWidth > 1024) {
        setLoadVideo(true);
      }
    }
  }, []);

  const handleLoadVideo = () => {
    setLoadVideo(true);
  };

  const isFrench = i18n.language === 'fr';

  return (
    <div className="w-full lg:w-1/2 relative">
      <div className="aspect-video rounded-xl overflow-hidden bg-[#0a0f0d] border border-[#00a1e0]/20">
        {loadVideo ? (
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            poster="/videos/sap-teched-poster.jpg"
            controls
            preload="metadata"
          >
            {/* Version légère pour mobile (à créer avec ffmpeg) */}
            <source 
              src="/videos/sap-teched-2025-mobile.mp4" 
              type="video/mp4"
              media="(max-width: 768px)"
            />
            {/* Version HD pour desktop */}
            <source src="/videos/sap-teched-2025.mp4" type="video/mp4" />
            {isFrench ? 'Votre navigateur ne supporte pas la lecture vidéo.' : 'Your browser does not support video playback.'}
          </video>
        ) : (
          <div 
            className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-[#00a1e0]/10 to-[#0070ad]/10 cursor-pointer group"
            onClick={handleLoadVideo}
          >
            {/* Poster image en arrière-plan */}
            <div 
              className="absolute inset-0 bg-cover bg-center opacity-30"
              style={{ backgroundImage: 'url(/videos/sap-teched-poster.jpg)' }}
            />
            
            <div className="relative z-10 text-center p-4">
              {/* Play button */}
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#00a1e0] flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg shadow-[#00a1e0]/30">
                <Play size={28} className="text-white ml-1" fill="white" />
              </div>
              
              {/* Info connexion */}
              <div className="flex items-center justify-center gap-2 mb-2">
                {isSlowConnection ? (
                  <WifiOff size={14} className="text-yellow-500" />
                ) : (
                  <Wifi size={14} className="text-[#00a1e0]" />
                )}
                <span className="text-xs text-gray-400 font-mono">
                  {connectionType !== 'unknown' ? connectionType.toUpperCase() : 'WiFi/4G'}
                </span>
              </div>
              
              {/* Message */}
              <p className="text-white text-sm font-medium mb-1">
                {isFrench ? 'Charger la vidéo' : 'Load video'}
              </p>
              <p className="text-gray-400 text-xs">
                {isFrench ? '~50 Mo (version optimisée mobile)' : '~50 MB (mobile optimized)'}
              </p>
              
              {/* Avertissement data */}
              {isSlowConnection && (
                <p className="text-yellow-500/80 text-xs mt-2 flex items-center justify-center gap-1">
                  <Download size={12} />
                  {isFrench ? 'Connexion lente détectée' : 'Slow connection detected'}
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const projects = [
  {
    id: 'ebmc',
    url: 'https://ebmc-group.com/',
    github: null,
    icon: mdiDomain,
    tags: ['React', 'Vite', 'Tailwind', 'SEO'],
    color: '#00ff88',
    category: 'web',
  },
  {
    id: 'amap',
    url: 'https://lespaniersdeleopold.fr/',
    github: null,
    icon: mdiBasket,
    tags: ['React', 'Tailwind', 'Docker', 'Cloudflare'],
    color: '#8BC34A',
    category: 'web',
  },
  {
    id: 'raytracing',
    url: null,
    github: 'https://github.com/BorisHenne/RT',
    icon: mdiCubeOutline,
    tags: ['C', 'Raytracing', '3D', 'École 42', 'Team Project'],
    color: '#f472b6',
    category: '42',
  },
  {
    id: 'libasm',
    url: null,
    github: 'https://github.com/BorisHenne/lib_ASM',
    icon: mdiMemory,
    tags: ['Assembly', 'x86-64', 'Low-level', 'École 42'],
    color: '#fbbf24',
    category: '42',
  },
  {
    id: 'homeassistant',
    url: null,
    github: null,
    icon: mdiHomeAutomation,
    tags: ['Home Assistant', 'IoT', 'Automation', 'YAML'],
    color: '#18bcf2',
    category: 'personal',
  },
  {
    id: 'suno',
    url: 'https://suno.com/@prompted57',
    github: null,
    icon: mdiMusic,
    tags: ['Suno AI', 'Music', 'Prompt Engineering', 'Hobby'],
    color: '#ec4899',
    category: 'personal',
  },
  {
    id: 'portfolio',
    url: 'https://boris-henne.fr/',
    github: 'https://github.com/BorisHenne',
    icon: mdiWeb,
    tags: ['React', 'Vite', 'Tailwind', 'Framer Motion'],
    color: '#a855f7',
    category: 'web',
  },
];

const categories = [
  { id: 'all', labelFr: 'Tous', labelEn: 'All' },
  { id: 'web', labelFr: 'Web', labelEn: 'Web' },
  { id: '42', labelFr: 'École 42', labelEn: 'School 42' },
  { id: 'personal', labelFr: 'Personnel', labelEn: 'Personal' },
];

export default function Projects() {
  const { t, i18n } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const [filter, setFilter] = useState('all');

  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(p => p.category === filter);

  return (
    <section id="projects" className="py-20 lg:py-32 relative bg-gradient-to-b from-transparent via-[#00ff88]/5 to-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            <span className="text-[#00ff88]">{'<'}</span>
            {t('projects.title')}
            <span className="text-[#00ff88]">{' />'}</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-[#00ff88] to-[#14b8a6] mx-auto rounded-full" />
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="flex justify-center gap-2 mb-10 flex-wrap"
        >
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFilter(cat.id)}
              className={`px-4 py-2 rounded-full font-mono text-sm transition-all ${
                filter === cat.id
                  ? 'bg-[#00ff88] text-[#0a0f0d] font-medium'
                  : 'bg-[#0a0f0d]/50 text-gray-400 border border-gray-700/50 hover:border-[#00ff88]/30 hover:text-[#00ff88]'
              }`}
            >
              {i18n.language === 'fr' ? cat.labelFr : cat.labelEn}
            </button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2 + index * 0.1 }}
              layout
              className="group"
            >
              <div className="glass-card rounded-2xl p-6 h-full flex flex-col hover:border-[#00ff88]/30 transition-all">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110"
                    style={{ backgroundColor: `${project.color}20` }}
                  >
                    <Icon path={project.icon} size={1.2} color={project.color} />
                  </div>
                  
                  <div className="flex gap-2">
                    {project.github && (
                      <a
                        href={project.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-lg text-gray-400 hover:text-[#00ff88] hover:bg-[#00ff88]/10 transition-all"
                        title="GitHub"
                      >
                        <Github size={20} />
                      </a>
                    )}
                    {project.url && (
                      <a
                        href={project.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-lg text-gray-400 hover:text-[#00ff88] hover:bg-[#00ff88]/10 transition-all"
                        title="Voir le site"
                      >
                        <ExternalLink size={20} />
                      </a>
                    )}
                  </div>
                </div>

                {/* Badge 42 */}
                {project.category === '42' && (
                  <div className="mb-3">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/10 border border-white/20 text-white text-xs font-mono">
                      <Icon path={mdiSchool} size={0.6} />
                      <span className="font-bold">42</span> Project
                    </span>
                  </div>
                )}

                {/* Content */}
                <h3 className="font-display text-xl text-white mb-3 group-hover:text-[#00ff88] transition-colors">
                  {t(`projects.list.${project.id}.title`)}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed mb-4 flex-1">
                  {t(`projects.list.${project.id}.description`)}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 text-xs font-mono rounded-full"
                      style={{
                        backgroundColor: `${project.color}15`,
                        color: project.color,
                        border: `1px solid ${project.color}30`,
                      }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* École 42 Mindset Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8 }}
          className="mt-16"
        >
          <div className="glass-card rounded-2xl p-6 md:p-8 border-white/20 relative overflow-hidden">
            {/* Background decoration */}
            <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-white/10 to-transparent rounded-full blur-3xl" />
            
            <div className="relative">
              <div className="flex flex-col md:flex-row items-start gap-6">
                {/* 42 Logo */}
                <div className="w-20 h-20 rounded-2xl bg-white flex items-center justify-center flex-shrink-0">
                  <Icon path={mdiSchool} size={2.5} color="#0a0f0d" />
                </div>
                
                <div className="flex-1">
                  <h3 className="font-display text-2xl text-white mb-3">
                    {t('education.school42Mindset.title')}
                  </h3>
                  <p className="text-gray-400 text-sm leading-relaxed mb-6">
                    {t('education.school42Mindset.description')}
                  </p>
                  
                  {/* Values */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {['autonomy', 'peerLearning', 'problemSolving', 'noLimits'].map((value) => (
                      <div
                        key={value}
                        className="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-center"
                      >
                        <span className="text-white text-xs font-mono">
                          {t(`education.school42Mindset.values.${value}`)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* SAP TechEd Highlight with Video */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.9 }}
          className="mt-8"
        >
          <div className="glass-card rounded-2xl p-6 md:p-8 border-[#00a1e0]/30 overflow-hidden">
            <div className="flex flex-col lg:flex-row items-center gap-6 lg:gap-8">
              {/* Video Player with Data Saver */}
              <VideoPlayer />
              
              {/* Content */}
              <div className="w-full lg:w-1/2 text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start gap-4 mb-4">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#00a1e0] to-[#0070ad] flex items-center justify-center flex-shrink-0">
                    <Icon path={mdiOfficeBuilding} size={2} color="white" />
                  </div>
                  <div>
                    <h3 className="font-display text-xl text-white">
                      SAP TechEd 2025
                    </h3>
                    <p className="text-[#00a1e0] text-sm font-mono">Berlin, Germany</p>
                  </div>
                </div>
                
                <p className="text-gray-400 text-sm mb-4">
                  VINCI Construction × EBMC Group - Participant et contributeur à l'événement majeur de la communauté SAP mondiale.
                </p>
                
                <div className="flex flex-wrap justify-center lg:justify-start gap-2">
                  {['SAP AI Hub', 'ABAP Cloud', 'Fiori Elements', 'RAP', 'Clean Core'].map((tag) => (
                    <span key={tag} className="px-3 py-1 text-xs font-mono rounded-full bg-[#00a1e0]/10 text-[#00a1e0] border border-[#00a1e0]/30">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* GitHub Link */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1 }}
          className="mt-10 text-center"
        >
          <a
            href="https://github.com/BorisHenne"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 btn-cyber"
          >
            <Github size={20} />
            {i18n.language === 'fr' ? 'Voir tous mes projets sur GitHub' : 'View all my projects on GitHub'}
          </a>
        </motion.div>
      </div>
    </section>
  );
}
