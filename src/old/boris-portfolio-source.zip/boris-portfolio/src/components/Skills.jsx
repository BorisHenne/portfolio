import { motion, useInView } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useRef, useState } from 'react';
import { Database, Layout, Server, Workflow, Wrench, Sparkles } from 'lucide-react';

const skillCategories = [
  {
    id: 'sap',
    icon: Database,
    color: '#00ff88',
    skills: [
      { name: 'ABAP / ABAP-OO', level: 95 },
      { name: 'SAP Fiori / UI5', level: 90 },
      { name: 'CDS / OData', level: 88 },
      { name: 'BAPI / RFC / IDoc', level: 92 },
      { name: 'Adobe LiveCycle', level: 85 },
      { name: 'Enhancement Points', level: 90 },
      { name: 'SAP ERP (FI/CO/MM/SD)', level: 85 },
    ],
  },
  {
    id: 'ai',
    icon: Sparkles,
    color: '#a855f7',
    skills: [
      { name: 'Claude (Anthropic)', level: 95 },
      { name: 'ChatGPT / GPT-4', level: 90 },
      { name: 'GitHub Copilot', level: 88 },
      { name: 'SAP Joule', level: 82 },
      { name: 'ABAP-1 (SAP AI)', level: 78 },
      { name: 'Prompt Engineering', level: 90 },
      { name: 'MCP (Model Context Protocol)', level: 85 },
    ],
  },
  {
    id: 'frontend',
    icon: Layout,
    color: '#14b8a6',
    skills: [
      { name: 'React / Next.js', level: 88 },
      { name: 'TypeScript', level: 82 },
      { name: 'Tailwind CSS', level: 90 },
      { name: 'Framer Motion', level: 85 },
      { name: 'Angular', level: 75 },
      { name: 'WordPress / Divi', level: 80 },
    ],
  },
  {
    id: 'backend',
    icon: Server,
    color: '#22d3ee',
    skills: [
      { name: 'Node.js', level: 80 },
      { name: 'PHP', level: 78 },
      { name: 'Python', level: 72 },
      { name: 'REST API', level: 90 },
      { name: 'SQL / Databases', level: 88 },
    ],
  },
  {
    id: 'automation',
    icon: Workflow,
    color: '#f472b6',
    skills: [
      { name: 'Make.com', level: 92 },
      { name: 'Home Assistant', level: 88 },
      { name: 'API Integration', level: 90 },
      { name: 'Workflow Automation', level: 92 },
    ],
  },
  {
    id: 'tools',
    icon: Wrench,
    color: '#fbbf24',
    skills: [
      { name: 'Git / GitHub', level: 88 },
      { name: 'Docker', level: 82 },
      { name: 'Cloudflare', level: 85 },
      { name: 'Linux / NAS', level: 80 },
      { name: 'VS Code / Eclipse', level: 92 },
    ],
  },
];

function SkillBar({ name, level, color, delay, isInView }) {
  return (
    <div className="mb-4 last:mb-0">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm text-gray-300">{name}</span>
        <span className="text-xs font-mono text-gray-500">{level}%</span>
      </div>
      <div className="skill-bar">
        <motion.div
          className="skill-bar-fill"
          style={{ background: `linear-gradient(90deg, ${color}, ${color}88)` }}
          initial={{ width: 0 }}
          animate={isInView ? { width: `${level}%` } : { width: 0 }}
          transition={{ duration: 1, delay: delay, ease: 'easeOut' }}
        />
      </div>
    </div>
  );
}

export default function Skills() {
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const [activeCategory, setActiveCategory] = useState('sap');

  return (
    <section id="skills" className="py-20 lg:py-32 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            <span className="text-[#00ff88]">{'<'}</span>
            {t('skills.title')}
            <span className="text-[#00ff88]">{' />'}</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-[#00ff88] to-[#14b8a6] mx-auto rounded-full" />
        </motion.div>

        {/* Category Tabs - Grid responsive pour mobile, flex pour desktop */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 gap-2 mb-8 sm:flex sm:flex-wrap sm:justify-center sm:gap-2"
        >
          {skillCategories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl font-mono text-xs sm:text-sm transition-all ${
                activeCategory === category.id
                  ? 'bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/50'
                  : 'bg-[#0a0f0d]/50 text-gray-400 border border-gray-700/50 hover:border-[#00ff88]/30'
              }`}
            >
              <category.icon size={16} className="sm:w-[18px] sm:h-[18px]" style={{ color: category.color }} />
              <span className="truncate">{t(`skills.categories.${category.id}`)}</span>
            </button>
          ))}
        </motion.div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories
            .filter((cat) => cat.id === activeCategory)
            .map((category) => (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                className="md:col-span-2 lg:col-span-3"
              >
                {/* Mobile: single card, Desktop: 2 columns */}
                <div className="glass-card rounded-2xl p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${category.color}20` }}
                    >
                      <category.icon size={22} style={{ color: category.color }} />
                    </div>
                    <h3 className="font-display text-xl text-white">
                      {t(`skills.categories.${category.id}`)}
                    </h3>
                  </div>
                  
                  {/* Skills in responsive grid */}
                  <div className="grid md:grid-cols-2 gap-x-8 gap-y-0">
                    {category.skills.map((skill, index) => (
                      <SkillBar
                        key={skill.name}
                        {...skill}
                        color={category.color}
                        delay={0.1 * index}
                        isInView={isInView}
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
        </div>

        {/* Quick Overview Tags */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6 }}
          className="mt-12 flex flex-wrap justify-center gap-3"
        >
          {['SAP', 'ABAP', 'Fiori', 'Claude', 'GPT', 'React', 'Make.com', 'Docker', 'Home Assistant', 'TypeScript'].map(
            (tag, index) => (
              <motion.span
                key={tag}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 0.7 + index * 0.05 }}
                className="px-4 py-2 rounded-full text-sm font-mono bg-gradient-to-r from-[#00ff88]/10 to-[#14b8a6]/10 border border-[#00ff88]/20 text-gray-300 hover:border-[#00ff88]/50 hover:text-[#00ff88] transition-all cursor-default"
              >
                {tag}
              </motion.span>
            )
          )}
        </motion.div>
      </div>
    </section>
  );
}
