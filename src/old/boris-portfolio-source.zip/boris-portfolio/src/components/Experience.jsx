import { motion, useInView } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useRef, useState } from 'react';
import { Briefcase, GraduationCap, MapPin, ChevronDown, ChevronUp } from 'lucide-react';

const experiences = [
  { id: 'ebmc', current: true },
  { id: 'ekenz1', current: false },
  { id: 'reprise', current: false },
  { id: 'censio', current: false },
  { id: 'etam', current: false },
  { id: 'freelance', current: false },
  { id: 'danone', current: false },
];

const education = [
  { id: 'school42' },
  { id: 'iutMetz' },
  { id: 'iutEpinal' },
  { id: 'ufaNancy' },
];

export default function Experience() {
  const { t, i18n } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const [showAllExp, setShowAllExp] = useState(false);
  const [showAllEdu, setShowAllEdu] = useState(false);

  const visibleExperiences = showAllExp ? experiences : experiences.slice(0, 4);
  const visibleEducation = showAllEdu ? education : education.slice(0, 2);

  return (
    <section id="experience" className="py-20 lg:py-32 relative bg-gradient-to-b from-transparent via-[#00ff88]/5 to-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            <span className="text-[#00ff88]">{'<'}</span>
            {t('experience.title')}
            <span className="text-[#00ff88]">{' />'}</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-[#00ff88] to-[#14b8a6] mx-auto rounded-full" />
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Experience Column */}
          <div>
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.2 }}
              className="flex items-center gap-3 mb-8"
            >
              <div className="w-12 h-12 rounded-xl bg-[#00ff88]/10 border border-[#00ff88]/30 flex items-center justify-center">
                <Briefcase className="text-[#00ff88]" size={24} />
              </div>
              <h3 className="font-display text-2xl text-white">
                {t('experience.title')}
              </h3>
            </motion.div>

            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-[#00ff88] via-[#00ff88]/50 to-transparent" />

              <div className="space-y-6">
                {visibleExperiences.map((exp, index) => (
                  <motion.div
                    key={exp.id}
                    initial={{ opacity: 0, x: -30 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.3 + index * 0.1 }}
                    className="relative pl-16"
                  >
                    {/* Timeline dot */}
                    <div className={`absolute left-4 top-2 w-5 h-5 rounded-full border-2 ${
                      exp.current 
                        ? 'bg-[#00ff88] border-[#00ff88] animate-pulse' 
                        : 'bg-[#0a0f0d] border-[#00ff88]/50'
                    }`} />

                    <div className="glass-card rounded-xl p-5 hover:border-[#00ff88]/40 transition-all">
                      <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                        <h4 className="font-display text-lg text-white">
                          {t(`experience.positions.${exp.id}.title`)}
                        </h4>
                        {exp.current && (
                          <span className="px-2 py-1 text-xs font-mono bg-[#00ff88]/20 text-[#00ff88] rounded-full">
                            {t('experience.present')}
                          </span>
                        )}
                      </div>
                      <p className="font-mono text-[#00ff88] text-sm mb-2">
                        {t(`experience.positions.${exp.id}.company`)}
                      </p>
                      <div className="flex flex-wrap items-center gap-4 text-gray-500 text-xs mb-3">
                        <span>{t(`experience.positions.${exp.id}.period`)}</span>
                        <span className="flex items-center gap-1">
                          <MapPin size={12} />
                          {t(`experience.positions.${exp.id}.location`)}
                        </span>
                      </div>
                      <p className="text-gray-400 text-sm leading-relaxed">
                        {t(`experience.positions.${exp.id}.description`)}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>

              {experiences.length > 4 && (
                <motion.button
                  initial={{ opacity: 0 }}
                  animate={isInView ? { opacity: 1 } : {}}
                  onClick={() => setShowAllExp(!showAllExp)}
                  className="mt-6 ml-16 flex items-center gap-2 text-[#00ff88] hover:text-[#00ff88]/80 transition-colors font-mono text-sm"
                >
                  {showAllExp ? (
                    <>
                      <ChevronUp size={18} />
                      {i18n.language === 'fr' ? 'Voir moins' : 'Show less'}
                    </>
                  ) : (
                    <>
                      <ChevronDown size={18} />
                      {i18n.language === 'fr' ? `Voir plus (${experiences.length - 4})` : `Show more (${experiences.length - 4})`}
                    </>
                  )}
                </motion.button>
              )}
            </div>
          </div>

          {/* Education Column */}
          <div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.2 }}
              className="flex items-center gap-3 mb-8"
            >
              <div className="w-12 h-12 rounded-xl bg-[#00ff88]/10 border border-[#00ff88]/30 flex items-center justify-center">
                <GraduationCap className="text-[#00ff88]" size={24} />
              </div>
              <h3 className="font-display text-2xl text-white">
                {t('education.title')}
              </h3>
            </motion.div>

            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-[#14b8a6] via-[#14b8a6]/50 to-transparent" />

              <div className="space-y-6">
                {visibleEducation.map((edu, index) => (
                  <motion.div
                    key={edu.id}
                    initial={{ opacity: 0, x: 30 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.4 + index * 0.1 }}
                    className="relative pl-16"
                  >
                    {/* Timeline dot */}
                    <div className="absolute left-4 top-2 w-5 h-5 rounded-full border-2 bg-[#0a0f0d] border-[#14b8a6]/50" />

                    <div className="glass-card rounded-xl p-5 hover:border-[#14b8a6]/40 transition-all">
                      <h4 className="font-display text-lg text-white mb-1">
                        {t(`education.schools.${edu.id}.name`)}
                      </h4>
                      <p className="font-mono text-[#14b8a6] text-sm mb-2">
                        {t(`education.schools.${edu.id}.degree`)}
                      </p>
                      <p className="text-gray-500 text-xs mb-2">
                        {t(`education.schools.${edu.id}.period`)}
                      </p>
                      {edu.id === 'school42' && (
                        <p className="text-gray-400 text-sm">
                          {t(`education.schools.${edu.id}.description`)}
                        </p>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>

              {education.length > 2 && (
                <motion.button
                  initial={{ opacity: 0 }}
                  animate={isInView ? { opacity: 1 } : {}}
                  onClick={() => setShowAllEdu(!showAllEdu)}
                  className="mt-6 ml-16 flex items-center gap-2 text-[#14b8a6] hover:text-[#14b8a6]/80 transition-colors font-mono text-sm"
                >
                  {showAllEdu ? (
                    <>
                      <ChevronUp size={18} />
                      {i18n.language === 'fr' ? 'Voir moins' : 'Show less'}
                    </>
                  ) : (
                    <>
                      <ChevronDown size={18} />
                      {i18n.language === 'fr' ? `Voir plus (${education.length - 2})` : `Show more (${education.length - 2})`}
                    </>
                  )}
                </motion.button>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
