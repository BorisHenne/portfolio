import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Heart, Code, Linkedin, Github, Mail } from 'lucide-react';

export default function Footer() {
  const { t } = useTranslation();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-12 border-t border-[#00ff88]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo & Copyright */}
          <div className="flex flex-col items-center md:items-start gap-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#00ff88] to-[#14b8a6] flex items-center justify-center font-display font-bold text-sm text-[#0a0f0d]">
                BH
              </div>
              <span className="font-display text-white">Boris Henné</span>
            </div>
            <p className="text-gray-500 text-sm">
              © {currentYear} {t('footer.rights')}
            </p>
          </div>

          {/* Made with */}
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <span>{t('footer.madeWith')}</span>
            <Heart size={16} className="text-red-500 fill-red-500" />
            <span>{t('footer.and')}</span>
            <Code size={16} className="text-[#00ff88]" />
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-3">
            <motion.a
              href="https://www.linkedin.com/in/borishenne/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg border border-[#00ff88]/20 text-gray-400 hover:text-[#00ff88] hover:bg-[#00ff88]/10 transition-all"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <Linkedin size={18} />
            </motion.a>
            <motion.a
              href="https://github.com/borishenne"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg border border-[#00ff88]/20 text-gray-400 hover:text-[#00ff88] hover:bg-[#00ff88]/10 transition-all"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <Github size={18} />
            </motion.a>
            <motion.a
              href="mailto:contact@boris-henne.fr"
              className="p-2 rounded-lg border border-[#00ff88]/20 text-gray-400 hover:text-[#00ff88] hover:bg-[#00ff88]/10 transition-all"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <Mail size={18} />
            </motion.a>
          </div>
        </div>

        {/* Tech Stack */}
        <div className="mt-8 pt-8 border-t border-[#00ff88]/10">
          <div className="flex flex-wrap justify-center gap-4 text-xs font-mono text-gray-600">
            <span>React</span>
            <span>•</span>
            <span>Vite</span>
            <span>•</span>
            <span>Tailwind CSS</span>
            <span>•</span>
            <span>Framer Motion</span>
            <span>•</span>
            <span>Docker</span>
            <span>•</span>
            <span>Cloudflare</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
