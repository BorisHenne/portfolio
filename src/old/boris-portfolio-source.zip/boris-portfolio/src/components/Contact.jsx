import { motion, useInView } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useRef, useState, useEffect } from 'react';
import { Mail, Phone, Linkedin, MapPin, Send, CheckCircle, AlertCircle } from 'lucide-react';
import { getMailtoLink, getTelLink, getObfuscatedPhone, getObfuscatedEmail } from '../utils/contactProtection';

export default function Contact() {
  const { t } = useTranslation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  const [contactInfo, setContactInfo] = useState({ email: '', phone: '' });
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    message: '',
    // Honeypot field - les bots remplissent ce champ invisible
    website: '',
  });
  const [status, setStatus] = useState(null); // 'sending', 'success', 'error', 'spam'
  const [formLoadTime] = useState(Date.now()); // Anti-spam: temps de chargement
  const [submitCount, setSubmitCount] = useState(0); // Rate limiting

  // Charger les infos de contact côté client uniquement
  useEffect(() => {
    setContactInfo({
      email: getObfuscatedEmail(),
      emailPro: getObfuscatedEmail('pro'),
      phone: getObfuscatedPhone(),
    });
  }, []);

  // Validation anti-spam
  const validateSubmission = () => {
    // 1. Honeypot check - si rempli, c'est un bot
    if (formState.website) {
      console.warn('Honeypot triggered');
      return false;
    }

    // 2. Time check - formulaire rempli trop vite (moins de 3 secondes)
    const timeSinceLoad = Date.now() - formLoadTime;
    if (timeSinceLoad < 3000) {
      console.warn('Form submitted too quickly:', timeSinceLoad, 'ms');
      return false;
    }

    // 3. Rate limiting - max 3 soumissions par session
    if (submitCount >= 3) {
      console.warn('Rate limit exceeded');
      setStatus('spam');
      return false;
    }

    // 4. Basic content validation - message trop court
    if (formState.message.trim().length < 10) {
      return false;
    }

    // 5. Spam patterns detection
    const spamPatterns = [
      /\b(viagra|casino|lottery|winner|cryptocurrency|bitcoin|investment opportunity)\b/i,
      /\b(click here|act now|limited time|free money)\b/i,
      /(http[s]?:\/\/.*){3,}/i, // Plus de 2 URLs
      /(.)\1{10,}/i, // Caractère répété 10+ fois
    ];
    
    const fullText = `${formState.name} ${formState.email} ${formState.message}`;
    for (const pattern of spamPatterns) {
      if (pattern.test(fullText)) {
        console.warn('Spam pattern detected');
        return false;
      }
    }

    // 6. Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formState.email)) {
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation anti-spam
    if (!validateSubmission()) {
      // Fake success pour ne pas alerter les bots
      setStatus('success');
      setFormState({ name: '', email: '', message: '', website: '' });
      setTimeout(() => setStatus(null), 3000);
      return;
    }

    setSubmitCount(prev => prev + 1);
    setStatus('sending');

    try {
      // Envoi via Formspree
      const response = await fetch('https://formspree.io/f/mzznbgrq', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          name: formState.name,
          email: formState.email,
          message: formState.message,
          _subject: `🚀 Portfolio Contact - ${formState.name}`,
          // Formspree formatera automatiquement en HTML
          _template: 'table'
        })
      });

      if (response.ok) {
        setStatus('success');
        setFormState({ name: '', email: '', message: '', website: '' });
        setTimeout(() => setStatus(null), 5000);
      } else {
        throw new Error('Erreur envoi');
      }
    } catch (error) {
      console.error('Form error:', error);
      setStatus('error');
      setTimeout(() => setStatus(null), 5000);
    }
  };

  const contactMethods = [
    {
      icon: Mail,
      label: t('contact.email'),
      value: contactInfo.email,
      href: getMailtoLink(),
      color: '#00ff88',
    },
    {
      icon: Phone,
      label: t('contact.phone'),
      value: contactInfo.phone,
      href: getTelLink(),
      color: '#14b8a6',
    },
    {
      icon: Linkedin,
      label: t('contact.linkedin'),
      value: 'Boris HENNÉ',
      href: 'https://www.linkedin.com/in/borishenne/',
      color: '#0077b5',
    },
    {
      icon: MapPin,
      label: t('contact.location'),
      value: 'Thionville, France',
      href: null,
      color: '#f472b6',
    },
  ];

  return (
    <section id="contact" className="py-20 lg:py-32 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            <span className="text-[#00ff88]">{'<'}</span>
            {t('contact.title')}
            <span className="text-[#00ff88]">{' />'}</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            {t('contact.subtitle')}
          </p>
          <div className="w-24 h-1 bg-gradient-to-r from-[#00ff88] to-[#14b8a6] mx-auto rounded-full mt-4" />
        </motion.div>

        {/* Contact Methods - Full width on top */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {contactMethods.map((method, index) => (
              <motion.div
                key={method.label}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                {method.href ? (
                  <a
                    href={method.href}
                    target={method.href.startsWith('http') ? '_blank' : undefined}
                    rel={method.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                    className="glass-card rounded-xl p-4 sm:p-5 flex items-center gap-3 sm:gap-4 group block h-full"
                  >
                    <div
                      className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110"
                      style={{ backgroundColor: `${method.color}20` }}
                    >
                      <method.icon size={20} className="sm:w-6 sm:h-6" style={{ color: method.color }} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-gray-500 text-xs font-mono mb-0.5">
                        {method.label}
                      </p>
                      <p className="text-white text-xs sm:text-sm truncate group-hover:text-[#00ff88] transition-colors">
                        {method.value}
                      </p>
                    </div>
                  </a>
                ) : (
                  <div className="glass-card rounded-xl p-4 sm:p-5 flex items-center gap-3 sm:gap-4 h-full">
                    <div
                      className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${method.color}20` }}
                    >
                      <method.icon size={20} className="sm:w-6 sm:h-6" style={{ color: method.color }} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-gray-500 text-xs font-mono mb-0.5">
                        {method.label}
                      </p>
                      <p className="text-white text-xs sm:text-sm">
                        {method.value}
                      </p>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Contact Form - Centered below */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5 }}
          className="max-w-2xl mx-auto"
        >
          <form onSubmit={handleSubmit} className="glass-card rounded-2xl p-6 sm:p-8">
            {/* Honeypot field - invisible pour les humains, les bots le remplissent */}
            <div className="absolute opacity-0 pointer-events-none" style={{ position: 'absolute', left: '-9999px' }} aria-hidden="true">
              <label htmlFor="website">Website</label>
              <input
                type="text"
                id="website"
                name="website"
                tabIndex={-1}
                autoComplete="off"
                value={formState.website}
                onChange={(e) => setFormState({ ...formState, website: e.target.value })}
              />
            </div>

            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-mono text-gray-400 mb-2">
                  {t('contact.form.name')}
                </label>
                <input
                  type="text"
                  id="name"
                  required
                  value={formState.name}
                  onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg bg-[#0a0f0d] border border-[#00ff88]/20 text-white placeholder-gray-600 focus:border-[#00ff88] focus:outline-none focus:ring-1 focus:ring-[#00ff88]/50 transition-colors"
                  placeholder="John Doe"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-mono text-gray-400 mb-2">
                  {t('contact.form.email')}
                </label>
                <input
                  type="email"
                  id="email"
                  required
                  value={formState.email}
                  onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg bg-[#0a0f0d] border border-[#00ff88]/20 text-white placeholder-gray-600 focus:border-[#00ff88] focus:outline-none focus:ring-1 focus:ring-[#00ff88]/50 transition-colors"
                  placeholder="john@example.com"
                />
              </div>
            </div>

            <div className="mt-6">
              <label htmlFor="message" className="block text-sm font-mono text-gray-400 mb-2">
                {t('contact.form.message')}
              </label>
              <textarea
                id="message"
                required
                rows={5}
                value={formState.message}
                onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                className="w-full px-4 py-3 rounded-lg bg-[#0a0f0d] border border-[#00ff88]/20 text-white placeholder-gray-600 focus:border-[#00ff88] focus:outline-none focus:ring-1 focus:ring-[#00ff88]/50 transition-colors resize-none"
                placeholder="Votre message..."
              />
            </div>

            <button
              type="submit"
              disabled={status === 'sending'}
              className="w-full mt-6 btn-cyber btn-cyber-filled flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {status === 'sending' ? (
                <>
                  <span className="w-5 h-5 border-2 border-[#0a0f0d] border-t-transparent rounded-full animate-spin" />
                  {t('contact.form.sending')}
                </>
              ) : status === 'success' ? (
                <>
                  <CheckCircle size={18} />
                  {t('contact.form.success')}
                </>
              ) : status === 'error' ? (
                <>
                  <AlertCircle size={18} />
                  {t('contact.form.error')}
                </>
              ) : (
                <>
                  <Send size={18} />
                  {t('contact.form.send')}
                </>
              )}
            </button>
          </form>
        </motion.div>
      </div>
    </section>
  );
}
