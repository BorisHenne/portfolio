#!/bin/bash
#
# Script de vérification et préparation pour boris-henne.fr
# À exécuter AVANT deploy.sh pour vérifier que tout est en place
#

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo -e "${BLUE}==========================================${NC}"
echo -e "${BLUE}   Vérification du projet${NC}"
echo -e "${BLUE}==========================================${NC}"
echo ""

ERRORS=0

# Vérifier les fichiers essentiels
FILES=(
    "Dockerfile"
    "docker-compose.yml"
    "docker-compose.standalone.yml"
    "nginx.conf"
    "package.json"
    "vite.config.js"
    "tailwind.config.js"
    "index.html"
    "src/main.jsx"
    "src/App.jsx"
)

echo -e "${BLUE}[CHECK]${NC} Vérification des fichiers essentiels..."
echo ""

for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        echo -e "  ${GREEN}✓${NC} $file"
    else
        echo -e "  ${RED}✗${NC} $file ${RED}(MANQUANT)${NC}"
        ((ERRORS++))
    fi
done

# Vérifier les dossiers
DIRS=(
    "src/components"
    "src/i18n"
    "src/store"
    "src/styles"
    "src/utils"
    "public"
)

echo ""
echo -e "${BLUE}[CHECK]${NC} Vérification des dossiers..."
echo ""

for dir in "${DIRS[@]}"; do
    if [ -d "$dir" ]; then
        echo -e "  ${GREEN}✓${NC} $dir/"
    else
        echo -e "  ${RED}✗${NC} $dir/ ${RED}(MANQUANT)${NC}"
        ((ERRORS++))
    fi
done

# Vérifier les composants React
COMPONENTS=(
    "Header"
    "Hero"
    "About"
    "Experience"
    "Skills"
    "Projects"
    "Contact"
    "Footer"
    "AdminModal"
)

echo ""
echo -e "${BLUE}[CHECK]${NC} Vérification des composants React..."
echo ""

for comp in "${COMPONENTS[@]}"; do
    if [ -f "src/components/${comp}.jsx" ]; then
        echo -e "  ${GREEN}✓${NC} ${comp}.jsx"
    else
        echo -e "  ${RED}✗${NC} ${comp}.jsx ${RED}(MANQUANT)${NC}"
        ((ERRORS++))
    fi
done

# Vérifier Docker
echo ""
echo -e "${BLUE}[CHECK]${NC} Vérification de Docker..."
echo ""

if command -v docker &> /dev/null; then
    echo -e "  ${GREEN}✓${NC} Docker installé: $(docker --version | cut -d' ' -f3)"
else
    echo -e "  ${RED}✗${NC} Docker non trouvé"
    ((ERRORS++))
fi

if docker compose version &> /dev/null; then
    echo -e "  ${GREEN}✓${NC} Docker Compose: $(docker compose version --short)"
elif command -v docker-compose &> /dev/null; then
    echo -e "  ${GREEN}✓${NC} docker-compose: $(docker-compose --version | cut -d' ' -f4)"
else
    echo -e "  ${RED}✗${NC} Docker Compose non trouvé"
    ((ERRORS++))
fi

# Résumé
echo ""
echo "==========================================="

if [ $ERRORS -eq 0 ]; then
    echo -e "${GREEN}✓ Tout est prêt ! Vous pouvez lancer:${NC}"
    echo ""
    echo "  ./deploy.sh --standalone"
    echo ""
else
    echo -e "${RED}✗ $ERRORS erreur(s) détectée(s)${NC}"
    echo ""
    echo -e "${YELLOW}Vérifiez que vous avez bien extrait l'archive:${NC}"
    echo "  tar -xzvf boris-portfolio.tar.gz"
    echo ""
    echo -e "${YELLOW}Structure attendue:${NC}"
    echo "  site-perso/"
    echo "  ├── Dockerfile"
    echo "  ├── docker-compose.yml"
    echo "  ├── nginx.conf"
    echo "  ├── package.json"
    echo "  ├── src/"
    echo "  │   ├── components/"
    echo "  │   ├── App.jsx"
    echo "  │   └── ..."
    echo "  └── public/"
    echo ""
fi

exit $ERRORS
